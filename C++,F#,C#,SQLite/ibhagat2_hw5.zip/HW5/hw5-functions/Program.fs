﻿#light

open Functions

//
// main() program:  when you run as an .exe
//
[<EntryPoint>]
let main argv =
  printfn ""
  printfn ""
  printfn "** Run unit tests via Test>>Windows>>Test Explorer..."
  printfn ""
  printfn ""
  0 // return success

